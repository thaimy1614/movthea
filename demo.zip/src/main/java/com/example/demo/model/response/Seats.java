package com.example.demo.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Seats {
    private int number;
    private boolean status;
}
