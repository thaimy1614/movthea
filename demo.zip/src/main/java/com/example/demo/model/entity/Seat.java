package com.example.demo.model.entity;

public class Seat {
}
