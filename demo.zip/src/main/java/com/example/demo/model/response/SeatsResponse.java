package com.example.demo.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatsResponse {
    public boolean status;
    private int number;
}
