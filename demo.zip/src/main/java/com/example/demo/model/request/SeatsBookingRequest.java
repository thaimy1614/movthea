package com.example.demo.model.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatsBookingRequest {
    private Long idRoom;
    private String time;
}
